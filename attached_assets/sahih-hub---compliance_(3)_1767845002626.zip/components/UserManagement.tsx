import React from 'react';
import { User, Role } from '../types';
import { Shield, CheckCircle, Clock, UserPlus, Mail } from 'lucide-react';

interface UserManagementProps {
  users: User[];
}

const UserManagement: React.FC<UserManagementProps> = ({ users }) => {
  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200">
      <div className="p-5 border-b border-gray-200 flex justify-between items-center">
        <div>
            <h2 className="text-lg font-bold text-gray-800">Personnel Competence</h2>
            <p className="text-xs text-gray-500">Staff Induction & Access Control</p>
        </div>
        <button className="flex items-center space-x-1 bg-gray-900 text-white px-4 py-2 rounded shadow hover:bg-gray-800 transition-colors text-sm font-medium">
            <UserPlus className="w-4 h-4" />
            <span>Invite User</span>
        </button>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="bg-gray-50 text-gray-600 text-xs uppercase tracking-wider">
              <th className="px-6 py-4 font-semibold">Name & Email</th>
              <th className="px-6 py-4 font-semibold">Role</th>
              <th className="px-6 py-4 font-semibold">Joined</th>
              <th className="px-6 py-4 font-semibold">Induction Status</th>
              <th className="px-6 py-4 font-semibold">Action</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-100">
            {users.map(user => (
              <tr key={user.id} className="hover:bg-gray-50 transition-colors">
                <td className="px-6 py-4">
                  <div className="flex items-center">
                    <div className="h-10 w-10 rounded-full bg-sahih-100 flex items-center justify-center text-sahih-700 font-bold mr-3">
                        {user.name.charAt(0)}
                    </div>
                    <div>
                        <p className="text-sm font-medium text-gray-900">{user.name}</p>
                        <p className="text-xs text-gray-500">{user.email}</p>
                    </div>
                  </div>
                </td>
                <td className="px-6 py-4">
                   <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-50 text-blue-700 border border-blue-100">
                     <Shield className="w-3 h-3 mr-1" />
                     {user.role}
                   </span>
                </td>
                <td className="px-6 py-4 text-sm text-gray-600">
                    {user.dateJoined}
                </td>
                <td className="px-6 py-4">
                    {user.inductionStatus === 'Completed' ? (
                        <span className="flex items-center text-emerald-600 text-sm font-medium">
                            <CheckCircle className="w-4 h-4 mr-1.5" />
                            Completed
                        </span>
                    ) : (
                        <span className="flex items-center text-amber-600 text-sm font-medium">
                            <Clock className="w-4 h-4 mr-1.5" />
                            Pending
                        </span>
                    )}
                </td>
                <td className="px-6 py-4">
                    <button className="text-gray-400 hover:text-sahih-700 transition-colors" title="Resend Invite">
                        <Mail className="w-4 h-4" />
                    </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default UserManagement;