import React, { useState } from 'react';
import { Document, Role, User, DocStatus, DocCategory, ArchivedDocument } from '../types';
import { getStatusColor, getComplianceStatus } from '../constants';
import { Eye, Edit, CheckSquare, Trash2, Filter, FilePlus, Archive, History, X, PenTool, Lock } from 'lucide-react';

interface DocumentListProps {
  documents: Document[];
  currentUser: User;
  onUpdateStatus: (docId: string, newStatus: DocStatus) => void;
  onApprove: (docId: string, signature: string) => void;
  onDelete: (docId: string) => void;
}

const DocumentList: React.FC<DocumentListProps> = ({ documents, currentUser, onUpdateStatus, onApprove, onDelete }) => {
  const [filterCategory, setFilterCategory] = useState<string>('All');
  const [filterStatus, setFilterStatus] = useState<string>('All');
  
  // Modals state
  const [approveModalOpen, setApproveModalOpen] = useState(false);
  const [selectedDocId, setSelectedDocId] = useState<string | null>(null);
  const [signature, setSignature] = useState('');
  const [historyModalOpen, setHistoryModalOpen] = useState(false);
  const [selectedDocHistory, setSelectedDocHistory] = useState<Document | null>(null);

  const filteredDocs = documents.filter(doc => {
    const matchCat = filterCategory === 'All' || doc.category === filterCategory;
    const matchStat = filterStatus === 'All' || doc.status === filterStatus;
    return matchCat && matchStat;
  });

  const canApprove = currentUser.role === Role.QUALITY_MANAGER || currentUser.role === Role.ADMIN;
  const canReview = currentUser.role === Role.DEPT_HEAD || currentUser.role === Role.HR_MANAGER || canApprove;
  
  const handleOpenApprove = (docId: string) => {
      setSelectedDocId(docId);
      setSignature('');
      setApproveModalOpen(true);
  };

  const handleSubmitApproval = (e: React.FormEvent) => {
      e.preventDefault();
      if (selectedDocId && signature) {
          onApprove(selectedDocId, signature);
          setApproveModalOpen(false);
      }
  };

  const handleOpenHistory = (doc: Document) => {
      setSelectedDocHistory(doc);
      setHistoryModalOpen(true);
  };

  const getActionButtons = (doc: Document) => {
    const isOwner = doc.ownerId === currentUser.id;

    if (doc.status === DocStatus.DRAFT && isOwner) {
        return (
            <button 
                onClick={() => onUpdateStatus(doc.id, DocStatus.IN_REVIEW)}
                className="text-xs bg-blue-600 text-white px-2 py-1 rounded hover:bg-blue-700 transition-colors"
            >
                Submit Review
            </button>
        );
    }

    if (doc.status === DocStatus.IN_REVIEW && canReview) {
        return (
            <div className="flex space-x-1">
                <button 
                    onClick={() => handleOpenApprove(doc.id)}
                    className="flex items-center text-xs bg-emerald-600 text-white px-2 py-1 rounded hover:bg-emerald-700 transition-colors"
                >
                    <PenTool className="w-3 h-3 mr-1" />
                    Approve
                </button>
                 <button 
                    onClick={() => onUpdateStatus(doc.id, DocStatus.REJECTED)}
                    className="text-xs bg-red-600 text-white px-2 py-1 rounded hover:bg-red-700 transition-colors"
                >
                    Reject
                </button>
            </div>
        );
    }

    return <span className="text-xs text-gray-400">View Only</span>;
  };

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 relative">
      <div className="p-5 border-b border-gray-200 flex flex-col sm:flex-row justify-between items-center gap-4">
        <div>
           <h2 className="text-lg font-bold text-gray-800">Document Master List</h2>
           <p className="text-xs text-gray-500">ISO 17021 Controlled Documents</p>
        </div>
        
        <div className="flex items-center space-x-2">
            <div className="relative">
                <select 
                    className="appearance-none bg-gray-50 border border-gray-300 text-gray-700 py-2 pl-3 pr-8 rounded leading-tight focus:outline-none focus:bg-white focus:border-sahih-500 text-sm"
                    value={filterCategory}
                    onChange={(e) => setFilterCategory(e.target.value)}
                >
                    <option value="All">All Categories</option>
                    {Object.values(DocCategory).map(c => <option key={c} value={c}>{c}</option>)}
                </select>
                <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-gray-700">
                    <Filter className="h-4 w-4" />
                </div>
            </div>
            <button className="flex items-center space-x-1 bg-sahih-700 text-white px-4 py-2 rounded shadow hover:bg-sahih-800 transition-colors text-sm font-medium">
                <FilePlus className="w-4 h-4" />
                <span>New Doc</span>
            </button>
        </div>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse">
            <thead>
                <tr className="bg-gray-50 text-gray-600 text-xs uppercase tracking-wider">
                    <th className="px-6 py-4 font-semibold">ID & Title</th>
                    <th className="px-6 py-4 font-semibold">Ver</th>
                    <th className="px-6 py-4 font-semibold">Category</th>
                    <th className="px-6 py-4 font-semibold">Status</th>
                    <th className="px-6 py-4 font-semibold">Next Review</th>
                    <th className="px-6 py-4 font-semibold">Actions</th>
                </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
                {filteredDocs.map(doc => {
                    const statusColor = getStatusColor(doc.status);
                    const compliance = getComplianceStatus(doc.nextReviewDate);
                    
                    return (
                        <tr key={doc.id} className="hover:bg-gray-50 transition-colors">
                            <td className="px-6 py-4">
                                <div className="flex flex-col">
                                    <span className="font-medium text-gray-900 text-sm">{doc.title}</span>
                                    <span className="text-xs text-gray-500 font-mono">{doc.id}</span>
                                </div>
                            </td>
                            <td className="px-6 py-4 text-sm text-gray-600">{doc.version}</td>
                            <td className="px-6 py-4">
                                <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800">
                                    {doc.category}
                                </span>
                            </td>
                            <td className="px-6 py-4">
                                <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium border ${statusColor}`}>
                                    {doc.status}
                                </span>
                            </td>
                            <td className="px-6 py-4">
                                <div className="flex items-center">
                                    <div className={`w-2 h-2 rounded-full mr-2 ${compliance.text.includes('Non-Compliant') ? 'bg-red-500' : compliance.text.includes('Due') ? 'bg-amber-500' : 'bg-emerald-500'}`}></div>
                                    <span className="text-sm text-gray-600">{doc.nextReviewDate}</span>
                                </div>
                            </td>
                            <td className="px-6 py-4">
                                <div className="flex items-center gap-3">
                                    {getActionButtons(doc)}
                                    <button 
                                        onClick={() => handleOpenHistory(doc)}
                                        className="text-gray-400 hover:text-sahih-700 transition-colors" 
                                        title="View Version History"
                                    >
                                        <History className="w-4 h-4" />
                                    </button>
                                </div>
                            </td>
                        </tr>
                    );
                })}
            </tbody>
        </table>
      </div>
      
      {filteredDocs.length === 0 && (
          <div className="p-10 text-center text-gray-500">
              No documents found matching filters.
          </div>
      )}

      {/* Digital Signature Modal */}
      {approveModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50">
              <div className="bg-white rounded-lg shadow-xl w-full max-w-md p-6">
                  <div className="flex justify-between items-center mb-4">
                      <h3 className="text-lg font-bold text-gray-900 flex items-center">
                          <Lock className="w-5 h-5 mr-2 text-sahih-700" />
                          Digital Signature
                      </h3>
                      <button onClick={() => setApproveModalOpen(false)} className="text-gray-400 hover:text-gray-600">
                          <X className="w-5 h-5" />
                      </button>
                  </div>
                  <p className="text-sm text-gray-600 mb-4">
                      By signing this document, you certify that you have reviewed it and it meets all ISO 17021 requirements. This action is irreversible and recorded in the audit trail.
                  </p>
                  <form onSubmit={handleSubmitApproval}>
                      <div className="mb-4">
                          <label className="block text-xs font-bold text-gray-700 uppercase tracking-wide mb-2">
                              Type Full Name to Sign
                          </label>
                          <input 
                              type="text" 
                              value={signature}
                              onChange={(e) => setSignature(e.target.value)}
                              className="appearance-none block w-full bg-gray-50 text-gray-700 border border-gray-300 rounded py-3 px-4 leading-tight focus:outline-none focus:bg-white focus:border-sahih-500"
                              placeholder={currentUser.name}
                              required
                          />
                          {signature && signature !== currentUser.name && (
                              <p className="text-xs text-red-500 mt-1">Signature must match your user name exactly.</p>
                          )}
                      </div>
                      <div className="flex justify-end space-x-3">
                          <button 
                              type="button"
                              onClick={() => setApproveModalOpen(false)}
                              className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 rounded hover:bg-gray-200"
                          >
                              Cancel
                          </button>
                          <button 
                              type="submit"
                              disabled={signature !== currentUser.name}
                              className="px-4 py-2 text-sm font-medium text-white bg-sahih-700 rounded hover:bg-sahih-800 disabled:opacity-50 disabled:cursor-not-allowed"
                          >
                              Confirm & Sign
                          </button>
                      </div>
                  </form>
              </div>
          </div>
      )}

      {/* History Modal */}
      {historyModalOpen && selectedDocHistory && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50">
              <div className="bg-white rounded-lg shadow-xl w-full max-w-2xl p-6">
                  <div className="flex justify-between items-center mb-6">
                      <div>
                        <h3 className="text-lg font-bold text-gray-900">Version History</h3>
                        <p className="text-sm text-gray-500">{selectedDocHistory.id}: {selectedDocHistory.title}</p>
                      </div>
                      <button onClick={() => setHistoryModalOpen(false)} className="text-gray-400 hover:text-gray-600">
                          <X className="w-5 h-5" />
                      </button>
                  </div>
                  
                  <div className="overflow-hidden border border-gray-200 rounded-lg">
                      <table className="min-w-full divide-y divide-gray-200">
                          <thead className="bg-gray-50">
                              <tr>
                                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Version</th>
                                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date Archived</th>
                                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Approver</th>
                              </tr>
                          </thead>
                          <tbody className="bg-white divide-y divide-gray-200">
                                {/* Current Version */}
                                <tr className="bg-emerald-50">
                                  <td className="px-6 py-4 whitespace-nowrap text-sm font-bold text-gray-900">
                                      {selectedDocHistory.version} (Current)
                                  </td>
                                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                      -
                                  </td>
                                  <td className="px-6 py-4 whitespace-nowrap">
                                      <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-emerald-100 text-emerald-800">
                                          {selectedDocHistory.status}
                                      </span>
                                  </td>
                                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                      {selectedDocHistory.approvedBy || '-'}
                                  </td>
                              </tr>
                              {/* Archived Versions */}
                              {selectedDocHistory.archivedVersions.slice().reverse().map((ver, idx) => (
                                  <tr key={idx}>
                                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                          {ver.version}
                                      </td>
                                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                          {ver.archivedAt}
                                      </td>
                                      <td className="px-6 py-4 whitespace-nowrap">
                                          <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-gray-100 text-gray-800">
                                              {ver.status}
                                          </span>
                                      </td>
                                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                          {ver.approvedBy || '-'}
                                      </td>
                                  </tr>
                              ))}
                              {selectedDocHistory.archivedVersions.length === 0 && (
                                  <tr>
                                      <td colSpan={4} className="px-6 py-4 text-center text-sm text-gray-500">
                                          No previous versions archived.
                                      </td>
                                  </tr>
                              )}
                          </tbody>
                      </table>
                  </div>

                  <div className="mt-6 flex justify-end">
                      <button 
                          onClick={() => setHistoryModalOpen(false)}
                          className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 rounded hover:bg-gray-200"
                      >
                          Close
                      </button>
                  </div>
              </div>
          </div>
      )}
    </div>
  );
};

export default DocumentList;