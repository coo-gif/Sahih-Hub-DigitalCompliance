import React, { useMemo } from 'react';
import { Document, DocStatus } from '../types';
import { getComplianceStatus } from '../constants';
import { PieChart, Pie, Cell, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import { AlertTriangle, FileText, CheckCircle, Clock } from 'lucide-react';

interface DashboardProps {
  documents: Document[];
}

const Dashboard: React.FC<DashboardProps> = ({ documents }) => {
  const stats = useMemo(() => {
    const total = documents.length;
    const pending = documents.filter(d => d.status === DocStatus.IN_REVIEW || d.status === DocStatus.DRAFT).length;
    const overdue = documents.filter(d => {
      const { text } = getComplianceStatus(d.nextReviewDate);
      return text.includes('Non-Compliant');
    }).length;
    const dueSoon = documents.filter(d => {
      const { text } = getComplianceStatus(d.nextReviewDate);
      return text.includes('Review Due');
    }).length;

    return { total, pending, overdue, dueSoon };
  }, [documents]);

  const chartData = useMemo(() => {
    const counts = documents.reduce((acc, doc) => {
      acc[doc.status] = (acc[doc.status] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    return Object.keys(counts).map(key => ({ name: key, value: counts[key] }));
  }, [documents]);

  const COLORS = ['#10b981', '#3b82f6', '#9ca3af', '#ef4444', '#f59e0b'];

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-100 flex items-center space-x-4">
          <div className="p-3 bg-blue-50 rounded-full text-blue-600">
            <FileText className="w-6 h-6" />
          </div>
          <div>
            <p className="text-sm text-gray-500 font-medium">Total Documents</p>
            <h3 className="text-2xl font-bold text-gray-900">{stats.total}</h3>
          </div>
        </div>
        
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-100 flex items-center space-x-4">
          <div className="p-3 bg-amber-50 rounded-full text-amber-600">
            <Clock className="w-6 h-6" />
          </div>
          <div>
            <p className="text-sm text-gray-500 font-medium">Pending Action</p>
            <h3 className="text-2xl font-bold text-gray-900">{stats.pending}</h3>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-100 flex items-center space-x-4">
          <div className="p-3 bg-red-50 rounded-full text-red-600">
            <AlertTriangle className="w-6 h-6" />
          </div>
          <div>
            <p className="text-sm text-gray-500 font-medium">Non-Conformance</p>
            <h3 className="text-2xl font-bold text-red-600">{stats.overdue}</h3>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-100 flex items-center space-x-4">
          <div className="p-3 bg-sahih-100 rounded-full text-sahih-700">
            <CheckCircle className="w-6 h-6" />
          </div>
          <div>
            <p className="text-sm text-gray-500 font-medium">Audit Ready</p>
            <h3 className="text-2xl font-bold text-gray-900">{((stats.total - stats.overdue)/stats.total * 100).toFixed(0)}%</h3>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Chart Section */}
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-100">
          <h3 className="text-lg font-bold text-gray-800 mb-4">Document Status Distribution</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={chartData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={80}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {chartData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Alerts Section */}
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-100">
          <h3 className="text-lg font-bold text-gray-800 mb-4">Compliance Alerts</h3>
          <div className="space-y-3">
            {documents
              .filter(d => {
                 const status = getComplianceStatus(d.nextReviewDate);
                 return status.text.includes('Non-Compliant') || status.text.includes('Review Due');
              })
              .map(doc => {
                 const status = getComplianceStatus(doc.nextReviewDate);
                 return (
                  <div key={doc.id} className={`flex items-start p-3 rounded-md border ${status.bg} border-opacity-50`}>
                    <div className={`mt-0.5 ${status.color}`}>
                       {status.icon}
                    </div>
                    <div className="ml-3">
                      <p className={`text-sm font-medium ${status.color}`}>{status.text}</p>
                      <p className="text-sm text-gray-600 font-medium">{doc.id}: {doc.title}</p>
                      <p className="text-xs text-gray-500">Owner: {doc.createdBy} • Due: {doc.nextReviewDate}</p>
                    </div>
                  </div>
                 )
              })}
             {documents.every(d => !getComplianceStatus(d.nextReviewDate).text.includes('Non-Compliant') && !getComplianceStatus(d.nextReviewDate).text.includes('Review Due')) && (
                <div className="flex flex-col items-center justify-center h-40 text-gray-400">
                   <CheckCircle className="w-12 h-12 mb-2 text-emerald-200" />
                   <p>All documents are compliant.</p>
                </div>
             )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;