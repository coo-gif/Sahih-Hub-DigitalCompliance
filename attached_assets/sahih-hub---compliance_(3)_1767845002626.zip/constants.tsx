import { Role, User, Document, DocStatus, DocCategory } from './types';
import { ShieldCheck, AlertTriangle, XCircle, CheckCircle } from 'lucide-react';
import React from 'react';

// Mock Users (Employee Database)
export const MOCK_USERS: User[] = [
  { 
    id: 'u1', 
    employeeId: 'EMP-101',
    name: 'Ahmed Al-Mansour', 
    email: 'ahmed@sahih.qa', 
    role: Role.QUALITY_MANAGER, 
    department: 'Quality Assurance',
    jobTitle: 'Quality Manager',
    status: 'Active',
    inductionStatus: 'Completed', 
    dateJoined: '2023-01-10' 
  },
  { 
    id: 'u2', 
    employeeId: 'EMP-001',
    name: 'Sarah Johnson', 
    email: 'sarah@sahih.qa', 
    role: Role.ADMIN, 
    department: 'Operations',
    jobTitle: 'Operations Director',
    status: 'Active',
    inductionStatus: 'Completed', 
    dateJoined: '2022-11-05' 
  },
  { 
    id: 'u3', 
    employeeId: 'EMP-205',
    name: 'Khalid Hassan', 
    email: 'khalid@sahih.qa', 
    role: Role.DEPT_HEAD, 
    department: 'Engineering',
    jobTitle: 'Head of Engineering',
    status: 'Active',
    inductionStatus: 'Completed', 
    dateJoined: '2023-03-12' 
  },
  { 
    id: 'u4', 
    employeeId: 'EMP-302',
    name: 'Fatima Ali', 
    email: 'fatima@sahih.qa', 
    role: Role.STAFF, 
    department: 'IT Support',
    jobTitle: 'IT Specialist',
    status: 'Active',
    inductionStatus: 'Pending', 
    dateJoined: '2023-10-01' 
  },
  { 
    id: 'u5', 
    employeeId: 'EMP-501',
    name: 'Layla Mahmoud', 
    email: 'layla@sahih.qa', 
    role: Role.HR_MANAGER, 
    department: 'Human Resources',
    jobTitle: 'HR Manager',
    status: 'Active',
    inductionStatus: 'Completed', 
    dateJoined: '2023-06-15' 
  },
];

// Mock Documents
export const MOCK_DOCS: Document[] = [
  {
    id: 'DOC-001',
    title: 'Quality Manual - ISO 17021',
    category: DocCategory.MANUAL,
    version: '2.0',
    status: DocStatus.APPROVED,
    createdBy: 'Ahmed Al-Mansour',
    ownerId: 'u1',
    approvedBy: 'Sarah Johnson',
    nextReviewDate: '2023-12-15', // Past date (Red Alert)
    archivedVersions: [
      { version: '1.0', archivedAt: '2022-01-15', status: DocStatus.OBSOLETE, approvedBy: 'Old Manager' }
    ],
    history: [
        { id: 'w1', stage: 'Approval', actorName: 'Sarah Johnson', action: 'Approved', timestamp: '2022-12-15' }
    ]
  },
  {
    id: 'SOP-HR-04',
    title: 'Auditor Competence Evaluation',
    category: DocCategory.SOP,
    version: '1.1',
    status: DocStatus.APPROVED,
    createdBy: 'Layla Mahmoud', // Created by HR
    ownerId: 'u5',
    approvedBy: 'Ahmed Al-Mansour',
    nextReviewDate: '2024-06-20', // Future date (Green)
    archivedVersions: [],
    history: []
  },
  {
    id: 'POL-IT-02',
    title: 'Data Retention Policy',
    category: DocCategory.POLICY,
    version: '0.9',
    status: DocStatus.IN_REVIEW,
    createdBy: 'Fatima Ali',
    ownerId: 'u4',
    nextReviewDate: '2024-05-30', // Near future
    archivedVersions: [],
    history: [
        { id: 'w2', stage: 'Draft', actorName: 'Fatima Ali', action: 'Created', timestamp: '2024-05-01' },
        { id: 'w3', stage: 'Review', actorName: 'Fatima Ali', action: 'Submitted for Review', timestamp: '2024-05-02' }
    ]
  },
  {
    id: 'SOP-OPS-09',
    title: 'Client Application Review',
    category: DocCategory.SOP,
    version: '3.0',
    status: DocStatus.APPROVED,
    createdBy: 'Ahmed Al-Mansour',
    ownerId: 'u1',
    approvedBy: 'Sarah Johnson',
    nextReviewDate: '2024-05-25', // Within 30 days (Yellow Alert)
    archivedVersions: [],
    history: []
  }
];

export const getStatusColor = (status: DocStatus) => {
  switch (status) {
    case DocStatus.APPROVED: return 'bg-emerald-100 text-emerald-800 border-emerald-200';
    case DocStatus.IN_REVIEW: return 'bg-blue-100 text-blue-800 border-blue-200';
    case DocStatus.DRAFT: return 'bg-gray-100 text-gray-800 border-gray-200';
    case DocStatus.OBSOLETE: return 'bg-red-100 text-red-800 border-red-200';
    case DocStatus.REJECTED: return 'bg-orange-100 text-orange-800 border-orange-200';
    default: return 'bg-gray-100 text-gray-800';
  }
};

export const getComplianceStatus = (nextReviewDate: string) => {
  const today = new Date();
  const reviewDate = new Date(nextReviewDate);
  const diffTime = reviewDate.getTime() - today.getTime();
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

  if (diffDays < 0) return { color: 'text-red-600', bg: 'bg-red-50', icon: <XCircle className="w-4 h-4 mr-1" />, text: 'Non-Compliant (Overdue)' };
  if (diffDays <= 30) return { color: 'text-amber-600', bg: 'bg-amber-50', icon: <AlertTriangle className="w-4 h-4 mr-1" />, text: `Review Due in ${diffDays} days` };
  return { color: 'text-emerald-600', bg: 'bg-emerald-50', icon: <CheckCircle className="w-4 h-4 mr-1" />, text: 'Compliant' };
};