import React, { useState, useEffect } from 'react';
import { Role, User, Document, PageView, DocStatus, ArchivedDocument, WorkflowLog } from './types';
import { MOCK_USERS, MOCK_DOCS } from './constants';
import Dashboard from './components/Dashboard';
import DocumentList from './components/DocumentList';
import UserManagement from './components/UserManagement';
import EmployeeDatabase from './components/EmployeeDatabase';
import { LayoutDashboard, FileText, Users, History, Bell, LogOut, ChevronDown, Menu, X, Briefcase, Lock } from 'lucide-react';

const App: React.FC = () => {
  const [activePage, setActivePage] = useState<PageView>('dashboard');
  const [currentUser, setCurrentUser] = useState<User>(MOCK_USERS[4]); // Default to HR Manager (Layla) for this demo
  const [documents, setDocuments] = useState<Document[]>(MOCK_DOCS);
  const [users, setUsers] = useState<User[]>(MOCK_USERS);
  const [sidebarOpen, setSidebarOpen] = useState(true);

  // User Management Handlers
  const handleAddUser = (newUser: User) => {
    setUsers([...users, newUser]);
  };

  const handleUpdateUser = (updatedUser: User) => {
    setUsers(users.map(u => u.id === updatedUser.id ? updatedUser : u));
  };

  // Helper to simulate DB updates for Doc Status
  const handleUpdateStatus = (docId: string, newStatus: DocStatus) => {
    setDocuments(prev => prev.map(doc => {
      if (doc.id === docId) {
        // Simple log for status change
        const log: WorkflowLog = {
          id: `log-${Date.now()}`,
          stage: newStatus === DocStatus.IN_REVIEW ? 'Review' : 'Draft',
          actorName: currentUser.name,
          action: `Status changed to ${newStatus}`,
          timestamp: new Date().toISOString().split('T')[0]
        };

        return { 
          ...doc, 
          status: newStatus,
          history: [...doc.history, log]
        };
      }
      return doc;
    }));
  };

  const handleApproveDocument = (docId: string, signature: string) => {
      setDocuments(prev => prev.map(doc => {
          if (doc.id !== docId) return doc;

          // 1. Create Archive Entry for the PREVIOUS state
          const archiveEntry: ArchivedDocument = {
              version: doc.version,
              archivedAt: new Date().toISOString().split('T')[0],
              status: doc.status,
              approvedBy: doc.approvedBy
          };

          // 2. Increment Version Logic
          let newVersion = doc.version;
          const verNum = parseFloat(doc.version);
          if (verNum < 1.0) {
              newVersion = '1.0'; // First approval usually brings draft to 1.0
          } else {
              newVersion = (verNum + 0.1).toFixed(1); // Increment minor version
          }

          // 3. Create Audit Log
          const auditLog: WorkflowLog = {
              id: `log-${Date.now()}`,
              stage: 'Approval',
              actorName: currentUser.name,
              action: 'Approved & Signed',
              timestamp: new Date().toISOString().split('T')[0],
              signature: signature,
              comments: `Version incremented from ${doc.version} to ${newVersion}`
          };

          return {
              ...doc,
              status: DocStatus.APPROVED,
              version: newVersion,
              approvedBy: currentUser.name,
              archivedVersions: [...doc.archivedVersions, archiveEntry],
              history: [...doc.history, auditLog]
          };
      }));
  };

  const handleDeleteDoc = (docId: string) => {
    setDocuments(prev => prev.filter(d => d.id !== docId));
  };

  // Navigation Items
  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'documents', label: 'Documents', icon: FileText },
    { id: 'users', label: 'User Management', icon: Users, roles: [Role.ADMIN] },
    { id: 'hr-department', label: 'HR Department', icon: Briefcase, roles: [Role.HR_MANAGER, Role.ADMIN] },
    { id: 'audit-trail', label: 'Audit Logs', icon: History },
  ];

  return (
    <div className="min-h-screen bg-gray-50 flex font-sans text-gray-900">
      
      {/* Mobile Sidebar Overlay */}
      {!sidebarOpen && (
        <div className="fixed inset-0 z-20 bg-black/50 lg:hidden" onClick={() => setSidebarOpen(true)}></div>
      )}

      {/* Sidebar */}
      <aside className={`fixed lg:static inset-y-0 left-0 z-30 w-64 bg-sahih-900 text-white transform transition-transform duration-200 ease-in-out ${!sidebarOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'} flex flex-col`}>
        <div className="h-16 flex items-center px-6 border-b border-sahih-800 bg-sahih-900">
           {/* Logo Simulation - Icon removed */}
           <div className="flex items-center gap-3">
              <div>
                <h1 className="font-bold text-lg leading-tight">Sahih</h1>
                <p className="text-[10px] text-sahih-200 uppercase tracking-wider">Certifications</p>
              </div>
           </div>
        </div>

        <nav className="flex-1 px-4 py-6 space-y-1">
          {navItems.filter(item => !item.roles || item.roles.includes(currentUser.role)).map((item) => {
            const Icon = item.icon;
            const isActive = activePage === item.id;
            return (
              <button
                key={item.id}
                onClick={() => {
                  setActivePage(item.id as PageView);
                  if (window.innerWidth < 1024) setSidebarOpen(true); // Close on mobile click
                }}
                className={`w-full flex items-center px-3 py-2.5 rounded-md text-sm font-medium transition-colors ${
                  isActive 
                    ? 'bg-sahih-800 text-white' 
                    : 'text-sahih-100 hover:bg-sahih-800 hover:text-white'
                }`}
              >
                <Icon className={`w-5 h-5 mr-3 ${isActive ? 'text-white' : 'text-sahih-300'}`} />
                {item.label}
              </button>
            );
          })}
        </nav>

        <div className="p-4 border-t border-sahih-800">
          <div className="bg-sahih-800 rounded-lg p-3">
            <p className="text-xs text-sahih-200 mb-1">Signed in as:</p>
            <div className="flex items-center justify-between">
               <span className="text-sm font-bold truncate mr-2">{currentUser.name}</span>
               <div className="w-2 h-2 bg-green-400 rounded-full"></div>
            </div>
            <p className="text-xs text-sahih-300 mt-0.5">{currentUser.role}</p>
          </div>
          
          {/* Debug Role Switcher - Essential for Demo */}
          <div className="mt-4 pt-4 border-t border-sahih-800">
            <label className="block text-xs text-sahih-400 mb-2">Simulate Role:</label>
            <select 
              className="w-full text-xs bg-sahih-900 border border-sahih-700 rounded text-white p-1"
              value={currentUser.id}
              onChange={(e) => {
                const user = users.find(u => u.id === e.target.value);
                if (user) setCurrentUser(user);
              }}
            >
              {users.map(u => (
                <option key={u.id} value={u.id}>{u.role}</option>
              ))}
            </select>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <div className="flex-1 flex flex-col min-h-0 overflow-hidden">
        
        {/* Top Header */}
        <header className="h-16 bg-white border-b border-gray-200 flex items-center justify-between px-4 lg:px-8">
          <button 
            onClick={() => setSidebarOpen(!sidebarOpen)}
            className="p-2 rounded-md text-gray-400 hover:text-gray-500 hover:bg-gray-100 focus:outline-none lg:hidden"
          >
            {sidebarOpen ? <Menu className="h-6 w-6" /> : <X className="h-6 w-6" />}
          </button>

          <div className="flex-1 flex justify-end items-center space-x-4">
             <button className="relative p-2 text-gray-400 hover:text-gray-500">
                <Bell className="w-5 h-5" />
                <span className="absolute top-1.5 right-1.5 block h-2 w-2 rounded-full bg-red-500 ring-2 ring-white"></span>
             </button>
             <div className="h-8 w-px bg-gray-200 mx-2"></div>
             <button className="flex items-center text-sm font-medium text-gray-700 hover:text-gray-900">
                <LogOut className="w-4 h-4 mr-2" />
                Logout
             </button>
          </div>
        </header>

        {/* Page Content */}
        <main className="flex-1 overflow-y-auto p-4 lg:p-8 bg-gray-50">
          <div className="max-w-7xl mx-auto">
             {activePage === 'dashboard' && <Dashboard documents={documents} />}
             {activePage === 'documents' && (
                <DocumentList 
                  documents={documents} 
                  currentUser={currentUser}
                  onUpdateStatus={handleUpdateStatus}
                  onApprove={handleApproveDocument}
                  onDelete={handleDeleteDoc}
                />
             )}
             {activePage === 'users' && <UserManagement users={users} />}
             {activePage === 'hr-department' && (
               <EmployeeDatabase 
                 users={users} 
                 onAddUser={handleAddUser}
                 onUpdateUser={handleUpdateUser}
               />
             )}
             {activePage === 'audit-trail' && (
               <div className="bg-white p-6 rounded shadow-sm">
                 <div className="flex items-center mb-6">
                    <History className="w-6 h-6 mr-2 text-sahih-700" />
                    <h3 className="text-lg font-bold text-gray-900">System Audit Trail</h3>
                 </div>
                 <div className="border border-gray-200 rounded-lg overflow-hidden">
                    <table className="min-w-full divide-y divide-gray-200">
                        <thead className="bg-gray-50">
                            <tr>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Timestamp</th>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Document ID</th>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">User</th>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Action</th>
                            </tr>
                        </thead>
                        <tbody className="bg-white divide-y divide-gray-200">
                            {documents.flatMap(doc => doc.history.map(log => ({ ...log, docId: doc.id }))).sort((a, b) => b.timestamp.localeCompare(a.timestamp)).map((log, idx) => (
                                <tr key={`${log.id}-${idx}`}>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{log.timestamp}</td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 font-mono">{log.docId}</td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{log.actorName}</td>
                                    <td className="px-6 py-4 text-sm text-gray-600">
                                        <div className="font-medium">{log.stage} - {log.action}</div>
                                        {log.comments && <div className="text-xs text-gray-500 italic mt-0.5">"{log.comments}"</div>}
                                        {log.signature && (
                                            <div className="flex items-center text-xs text-emerald-600 mt-1">
                                                <Lock className="w-3 h-3 mr-1" />
                                                Signed by {log.signature}
                                            </div>
                                        )}
                                    </td>
                                </tr>
                            ))}
                            {documents.flatMap(doc => doc.history).length === 0 && (
                                <tr>
                                    <td colSpan={4} className="px-6 py-4 text-center text-sm text-gray-500">No audit logs recorded.</td>
                                </tr>
                            )}
                        </tbody>
                    </table>
                 </div>
               </div>
             )}
          </div>
        </main>
      </div>
    </div>
  );
};

export default App;