export enum Role {
  ADMIN = 'Admin',
  QUALITY_MANAGER = 'Quality Manager', // Approver
  DEPT_HEAD = 'Department Head', // Reviewer
  HR_MANAGER = 'HR Manager', // New Department Role
  STAFF = 'Staff', // Creator/Viewer
  AUDITOR = 'Auditor'
}

export enum DocStatus {
  DRAFT = 'Draft',
  IN_REVIEW = 'In-Review',
  APPROVED = 'Approved',
  OBSOLETE = 'Obsolete',
  REJECTED = 'Rejected'
}

export enum DocCategory {
  POLICY = 'Policy',
  MANUAL = 'Manual',
  SOP = 'SOP',
  FORMAT = 'Format'
}

export type EmployeeStatus = 'Active' | 'On Leave' | 'Terminated';

export interface User {
  id: string; // System ID
  employeeId: string; // HR ID (e.g. EMP-001)
  name: string;
  email: string;
  role: Role;
  department: string;
  jobTitle: string;
  status: EmployeeStatus;
  inductionStatus: 'Pending' | 'Completed';
  dateJoined: string;
}

export interface WorkflowLog {
  id: string;
  stage: string;
  actorName: string;
  action: string;
  timestamp: string;
  comments?: string;
  signature?: string; // Digital signature
}

export interface ArchivedDocument {
  version: string;
  archivedAt: string;
  status: DocStatus;
  approvedBy?: string;
}

export interface Document {
  id: string;
  title: string;
  category: DocCategory;
  version: string;
  status: DocStatus;
  createdBy: string;
  ownerId: string;
  approvedBy?: string;
  nextReviewDate: string;
  content?: string;
  history: WorkflowLog[];
  archivedVersions: ArchivedDocument[];
}

export type PageView = 'dashboard' | 'documents' | 'users' | 'audit-trail' | 'hr-department';